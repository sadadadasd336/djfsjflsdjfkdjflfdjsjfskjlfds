import telebot
from telebot import types

# 🔒 Замени на свой токен (не публикуй его!)
bot = telebot.TeleBot("8457547365:AAGuiNep3tyGaRQbRGNJlgjnue4V9zP8W_w")

# Храним данные пользователей (временная база)
user_data = {}

# Команда /start
@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    if user_id not in user_data:
        user_data[user_id] = {
            "gifts": {
                "nft": [],
                "regular": {}
            }
        }

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("🎮 Играть")
    btn2 = types.KeyboardButton("👤 Профиль")
    btn3 = types.KeyboardButton("💬 Поддержка")
    markup.add(btn1, btn2, btn3)

    bot.send_message(
        message.chat.id,
        "🎁 Приветствуем вас в *GiftsAvia!*",
        parse_mode="Markdown",
        reply_markup=markup
    )

# Обработка нажатий кнопок
@bot.message_handler(func=lambda message: True)
def handle_message(message):
    user_id = message.from_user.id

    if message.text == "👤 Профиль":
        profile = user_data.get(user_id, {"gifts": {"nft": [], "regular": {}}})
        nft_list = profile["gifts"]["nft"]
        regular = profile["gifts"]["regular"]

        nft_text = "🖼 NFT подарки:\n" + ("\n".join(nft_list) if nft_list else "— нет —")
        reg_text = "\n🎁 Обычные подарки:\n"
        reg_text += "\n".join([f"{name} ×{count}" for name, count in regular.items()]) if regular else "— нет —"

        bot.send_message(message.chat.id, f"{nft_text}\n{reg_text}")

    elif message.text == "🎮 Играть":
        # Тут потом откроем мини-приложение
        markup = types.InlineKeyboardMarkup()
        web_btn = types.InlineKeyboardButton(
            text="🚀 Запустить мини-игру",
            web_app=types.WebAppInfo("https://your-mini-app-url.com")  # 🔗 заменим позже
        )
        markup.add(web_btn)
        bot.send_message(message.chat.id, "Запускаем мини-приложение...", reply_markup=markup)

    elif message.text == "💬 Поддержка":
        bot.send_message(message.chat.id, "Поддержка пока недоступна 🛠")

    else:
        bot.send_message(message.chat.id, "Выберите действие с помощью кнопок ниже 👇")

print("Бот запущен...")
bot.infinity_polling()
